-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: localhost    Database: movie_update
-- ------------------------------------------------------
-- Server version	5.7.44-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cloud_user`
--

DROP TABLE IF EXISTS `cloud_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cloud_user` (
  `cloud` text NOT NULL,
  `cookies` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cloud_user`
--

LOCK TABLES `cloud_user` WRITE;
/*!40000 ALTER TABLE `cloud_user` DISABLE KEYS */;
INSERT INTO `cloud_user` VALUES ('189','[{\"domain\": \".cloud.189.cn\", \"httpOnly\": true, \"name\": \"COOKIE_LOGIN_USER\", \"path\": \"/\", \"sameSite\": \"Lax\", \"secure\": false, \"value\": \"4BBEDAB6B5BB10A1D3DBB35B03BB32BFEAC15DA08D56D5CA23A93DD92D43E1F837CDEC74CC1A5D0FDC44957151A39E46432AF3BD1DE13417BA0413E2\"}, {\"domain\": \"cloud.189.cn\", \"expiry\": 1759742500, \"httpOnly\": false, \"name\": \"apm_ua\", \"path\": \"/\", \"sameSite\": \"Lax\", \"secure\": false, \"value\": \"E8DB1A910EE088B469ECFD2B6A9B9DA5\"}, {\"domain\": \"cloud.189.cn\", \"httpOnly\": true, \"name\": \"JSESSIONID\", \"path\": \"/\", \"sameSite\": \"Lax\", \"secure\": false, \"value\": \"C45D61A848055A3F6CADA23837AA9CC1\"}, {\"domain\": \"cloud.189.cn\", \"httpOnly\": false, \"name\": \"apm_sid\", \"path\": \"/\", \"sameSite\": \"Lax\", \"secure\": false, \"value\": \"7B347EF6885B499F29A472EFC8BEB646\"}, {\"domain\": \"cloud.189.cn\", \"expiry\": 1759742500, \"httpOnly\": false, \"name\": \"apm_ct\", \"path\": \"/\", \"sameSite\": \"Lax\", \"secure\": false, \"value\": \"20240901172141000\"}, {\"domain\": \"cloud.189.cn\", \"expiry\": 1759742500, \"httpOnly\": false, \"name\": \"apm_uid\", \"path\": \"/\", \"sameSite\": \"Lax\", \"secure\": false, \"value\": \"5CEE23996F9AB85A83011D861A82EBA4\"}, {\"domain\": \"cloud.189.cn\", \"expiry\": 1759742500, \"httpOnly\": false, \"name\": \"apm_key\", \"path\": \"/\", \"sameSite\": \"Lax\", \"secure\": false, \"value\": \"2CF41740FAF2D452893791EBFD29E195\"}]');
/*!40000 ALTER TABLE `cloud_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movie_data`
--

DROP TABLE IF EXISTS `movie_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `movie_data` (
  `name` text NOT NULL COMMENT '动漫名',
  `info_url` text NOT NULL COMMENT '详情页地址,用于获取最新集数',
  `update_url` text NOT NULL COMMENT '更新地址',
  `share_key` text COMMENT '分享码',
  `url_path` text COMMENT '地址路径',
  `save_path` text COMMENT '保存路径',
  `have_episodes` int(11) NOT NULL DEFAULT '0' COMMENT '现有集数',
  `update_time` date NOT NULL DEFAULT '2024-09-01' COMMENT '集数更新时间',
  `url_status` int(11) NOT NULL DEFAULT '1' COMMENT '更新地址状态,0为正常,1为失效',
  `update_interval` int(11) NOT NULL DEFAULT '7' COMMENT '更新间隔',
  `latest_episodes` int(11) NOT NULL DEFAULT '0' COMMENT '最新集数'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movie_data`
--

LOCK TABLES `movie_data` WRITE;
/*!40000 ALTER TABLE `movie_data` DISABLE KEYS */;
INSERT INTO `movie_data` VALUES ('剑来','https://v.qq.com/x/cover/mzc0020072zgk61.html','https://cloud.189.cn/web/share?code=BNJNR3aQBRVb',NULL,NULL,'剑来（2024）',6,'2024-09-04',1,7,6);
/*!40000 ALTER TABLE `movie_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'movie_update'
--

--
-- Dumping routines for database 'movie_update'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-06  0:16:23
