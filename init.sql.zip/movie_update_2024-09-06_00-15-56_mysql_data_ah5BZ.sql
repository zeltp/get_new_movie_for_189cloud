-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: localhost    Database: movie_update
-- ------------------------------------------------------
-- Server version	5.7.44-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cloud_user`
--

DROP TABLE IF EXISTS `cloud_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cloud_user` (
  `cloud` text NOT NULL,
  `cookies` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cloud_user`
--

LOCK TABLES `cloud_user` WRITE;
/*!40000 ALTER TABLE `cloud_user` DISABLE KEYS */;
INSERT INTO `cloud_user` VALUES ('189','[{\"domain\": \".cloud.189.cn\", \"httpOnly\": true, \"name\": \"COOKIE_LOGIN_USER\", \"path\": \"/\", \"sameSite\": \"Lax\", \"secure\": false, \"value\": \"4BBEDAB6B5BB10A1D3DBB35B03BB32BFEAC15DA08D56D5CA23A93DD92D43E1F837CDEC74CC1A5D0FDC44957151A39E46432AF3BD1DE13417BA0413E2\"}, {\"domain\": \"cloud.189.cn\", \"expiry\": 1759742500, \"httpOnly\": false, \"name\": \"apm_ua\", \"path\": \"/\", \"sameSite\": \"Lax\", \"secure\": false, \"value\": \"E8DB1A910EE088B469ECFD2B6A9B9DA5\"}, {\"domain\": \"cloud.189.cn\", \"httpOnly\": true, \"name\": \"JSESSIONID\", \"path\": \"/\", \"sameSite\": \"Lax\", \"secure\": false, \"value\": \"C45D61A848055A3F6CADA23837AA9CC1\"}, {\"domain\": \"cloud.189.cn\", \"httpOnly\": false, \"name\": \"apm_sid\", \"path\": \"/\", \"sameSite\": \"Lax\", \"secure\": false, \"value\": \"7B347EF6885B499F29A472EFC8BEB646\"}, {\"domain\": \"cloud.189.cn\", \"expiry\": 1759742500, \"httpOnly\": false, \"name\": \"apm_ct\", \"path\": \"/\", \"sameSite\": \"Lax\", \"secure\": false, \"value\": \"20240901172141000\"}, {\"domain\": \"cloud.189.cn\", \"expiry\": 1759742500, \"httpOnly\": false, \"name\": \"apm_uid\", \"path\": \"/\", \"sameSite\": \"Lax\", \"secure\": false, \"value\": \"5CEE23996F9AB85A83011D861A82EBA4\"}, {\"domain\": \"cloud.189.cn\", \"expiry\": 1759742500, \"httpOnly\": false, \"name\": \"apm_key\", \"path\": \"/\", \"sameSite\": \"Lax\", \"secure\": false, \"value\": \"2CF41740FAF2D452893791EBFD29E195\"}]');
/*!40000 ALTER TABLE `cloud_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movie_data`
--

DROP TABLE IF EXISTS `movie_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `movie_data` (
  `name` text NOT NULL COMMENT '动漫名',
  `info_url` text NOT NULL COMMENT '详情页地址,用于获取最新集数',
  `update_url` text NOT NULL COMMENT '更新地址',
  `share_key` text COMMENT '分享码',
  `url_path` text COMMENT '地址路径',
  `save_path` text COMMENT '保存路径',
  `have_episodes` int(11) NOT NULL DEFAULT '0' COMMENT '现有集数',
  `update_time` date NOT NULL DEFAULT '2024-09-01' COMMENT '集数更新时间',
  `url_status` int(11) NOT NULL DEFAULT '1' COMMENT '更新地址状态,0为正常,1为失效',
  `update_interval` int(11) NOT NULL DEFAULT '7' COMMENT '更新间隔',
  `latest_episodes` int(11) NOT NULL DEFAULT '0' COMMENT '最新集数'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movie_data`
--

LOCK TABLES `movie_data` WRITE;
/*!40000 ALTER TABLE `movie_data` DISABLE KEYS */;
INSERT INTO `movie_data` VALUES ('吞噬星空','https://v.qq.com/x/cover/324olz7ilvo2j5f.html','https://cloud.189.cn/web/share?code=JRNbInZZj2Ir','','第5季（2024）更新中','吞噬星空（2020）',135,'2024-09-02',1,7,135),('仙逆','https://v.qq.com/x/cover/mzc00200aaogpgh.html','https://cloud.189.cn/web/share?code=2auaemB3iqQv',NULL,'Season 1','仙逆（2023）',52,'2024-09-04',1,7,52),('剑来','https://v.qq.com/x/cover/mzc0020072zgk61.html','https://cloud.189.cn/web/share?code=BNJNR3aQBRVb',NULL,NULL,'剑来（2024）',6,'2024-09-04',1,7,6),('完美世界','https://v.qq.com/x/cover/mcv8hkc8zk8lnov.html','https://cloud.189.cn/web/share?code=aIZfYbmiy6Bb',NULL,'','完美世界（2021）',178,'2024-09-04',1,7,178),('一念永恒 第三季','https://v.qq.com/x/cover/mzc002003lw1kp8.html','https://cloud.189.cn/web/share?code=yMviquRfMZj2',NULL,'Season 03','一念永恒（2020）/Season 03',13,'2024-09-04',1,7,13),('神印王座','https://v.qq.com/x/cover/mzc002007j7p5hn.html','https://cloud.189.cn/web/share?code=2ENbUzBBbqqu',NULL,'Season 01','神印王座（2022）',122,'2024-09-04',1,7,122),('念无双','https://www.iqiyi.com/v_1cjd7975090.html?vfm=m_103_txsp','https://cloud.189.cn/web/share?code=32MFreFfeaUj',NULL,NULL,'念无双（2024）',6,'2024-09-04',1,7,6),('遮天','https://v.qq.com/x/cover/mzc00200n53vkqc.html','https://cloud.189.cn/web/share?code=vaUVN3NnuuUr',NULL,'Season 1','遮天（2023）',73,'2024-09-03',1,7,73),('师兄啊师兄','https://v.youku.com/v_show/id_XNTkzNjcwOTkwOA==.html','https://cloud.189.cn/web/share?code=Zv6r2aFF3imi',NULL,'Season 1','师兄啊师兄（2024）',52,'2024-09-04',1,7,52),('成何体统','https://www.iqiyi.com/v_1kkbzmq3woc.html?vfm=m_103_txsp','https://cloud.189.cn/web/share?code=jERVvmQR3I3u',NULL,'Season 01','成何体统（2024）',16,'2024-09-04',1,7,16),('百炼成神','https://v.youku.com/v_show/id_XNTkxNTE0MzIwMA==.html','https://cloud.189.cn/web/share?code=maEvQbz2qiQz',NULL,NULL,'百炼成神（2022）',92,'2024-09-04',1,7,92),('斗罗大陆II 绝世唐门','https://v.qq.com/x/cover/mzc00200xf3rir6.html','https://cloud.189.cn/web/share?code=3AvqmuryqUn2',NULL,NULL,'斗罗大陆Ⅱ绝世唐门 (2023)',64,'2024-09-04',1,7,64),('斗破苍穹年番','https://v.qq.com/x/cover/mzc0020027yzd9e.html','https://cloud.189.cn/web/share?code=qm6RBfeyi6Vf',NULL,NULL,'斗破苍穹（2017）/Season 05',110,'2024-09-01',1,7,110),('凡人修仙传','https://www.bilibili.com/bangumi/play/ss28747','https://cloud.189.cn/web/share?code=A7JNJjzqMzUv',NULL,' 5.凡人修仙传之星海飞驰','凡人修仙传（2020）/Season 05',117,'2024-09-04',1,7,117);
/*!40000 ALTER TABLE `movie_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'movie_update'
--

--
-- Dumping routines for database 'movie_update'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-06  0:15:56
